# GitList-Swift

GitList project is created using github public api where you can get details of public repository details which includes
Contributores Info, Size, Watcher Count, Fork count and many more information which is accessible.

Here's what it looks like:

![Output sample](https://github.com/anilg0403/GitList-Swift/blob/master/GithubApp/Resource/GitListAppDemo.gif)
