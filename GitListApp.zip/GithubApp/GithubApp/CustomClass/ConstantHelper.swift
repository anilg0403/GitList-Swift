//
//  ConstantHelper.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

let API_REPO_LIST : String = "https://api.github.com/search/repositories?q=language:"

