//
//  ThemeComponent.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import UIKit
import Foundation

enum fontString: String {
    case avenirBlack = "Avenir-Black"
    case avenirHeavy = "Avenir-Heavy"
    case avenirMedium = "Avenir-Medium"
    case avenirBook = "Avenir-Book"
}
