//
//  WelcomePresenter.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

class WelcomePresenter:ViewToPresenterProtocol {
    
    var view: PresenterToViewProtocol?
    var router: PresenterToRouterProtocol?
    
    func showRepoListController(navigationController: UINavigationController, selectedLanguage: String) {
        router?.pushToRepoListScreen(navigationConroller:navigationController, selectedLanguage:selectedLanguage)
    }

}
