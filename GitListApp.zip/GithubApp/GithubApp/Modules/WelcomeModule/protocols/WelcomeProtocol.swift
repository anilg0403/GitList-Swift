//
//  WelcomeProtocol.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

protocol ViewToPresenterProtocol: class{
    var view: PresenterToViewProtocol? {get set}
    var router: PresenterToRouterProtocol? {get set}
    func showRepoListController(navigationController:UINavigationController, selectedLanguage:String)
}

protocol PresenterToViewProtocol: class{
}

protocol PresenterToRouterProtocol: class {
    static func createModule()-> WelcomeViewController
    func pushToRepoListScreen(navigationConroller:UINavigationController,selectedLanguage:String)
}

//protocol PresenterToInteractorProtocol: class {
//    var presenter:InteractorToPresenterProtocol? {get set}
//    func fetchNotice()
//}

//protocol InteractorToPresenterProtocol: class {
//    func noticeFetchedSuccess(noticeModelArray:Array<NoticeModel>)
//    func noticeFetchFailed()
//}
