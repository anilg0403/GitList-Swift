//
//  WelcomeViewController.swift
//  GithubApp
//
//  Created by Anil Gupta on 05/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import UIKit

//MARK:- WelcomeViewController Class
class WelcomeViewController: UIViewController, PresenterToViewProtocol {
    
    //MARK:- IBOutlets
    @IBOutlet weak var parentWrapperView: UIView!
    
    //MARK:- Properties
    var presentor:ViewToPresenterProtocol?
    
    var selectedLanguage = ""
    var languageBtn = UIButton.init()
    var languageArray = [String]()
    
    var toolBar = UIToolbar()
    var picker  = UIPickerView()
    
    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        self.parentWrapperView.backgroundColor = UIColor.getColor(.base_1)
        self.languageArray = ["SWIFT","PHP","HTML"]
        self.setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.title = ""
    }
    
    //MARK:- UI Setup
    func setUI() {
        
        let shadowWrapperView = UIView.init()
        shadowWrapperView.backgroundColor = .clear
        shadowWrapperView.translatesAutoresizingMaskIntoConstraints = false
        parentWrapperView.addSubview(shadowWrapperView)
        shadowWrapperView.leadingAnchor.constraint(equalTo: parentWrapperView.leadingAnchor, constant:20).isActive = true
        shadowWrapperView.trailingAnchor.constraint(equalTo: parentWrapperView.trailingAnchor, constant:-20).isActive = true
        shadowWrapperView.topAnchor.constraint(equalTo:parentWrapperView.topAnchor, constant:60).isActive = true
        
        shadowWrapperView.backgroundColor = UIColor.getColor(.base_1)
        shadowWrapperView.layer.cornerRadius = 10
        shadowWrapperView.layer.shadowOffset = CGSize(width: 0, height:2)
        shadowWrapperView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.1).cgColor
        shadowWrapperView.layer.shadowOpacity = 1
        shadowWrapperView.layer.shadowRadius = 8
        
        let welcomeImage = UIImageView.init()
        welcomeImage.image = UIImage(named:"welcomeLogo")
        welcomeImage.translatesAutoresizingMaskIntoConstraints = false
        shadowWrapperView.addSubview(welcomeImage)
        welcomeImage.centerXAnchor.constraint(equalTo: shadowWrapperView.centerXAnchor, constant:0).isActive = true
        welcomeImage.topAnchor.constraint(equalTo: shadowWrapperView.topAnchor, constant:30).isActive = true
        welcomeImage.widthAnchor.constraint(equalTo: shadowWrapperView.widthAnchor, multiplier:0.3, constant:0).isActive = true
        welcomeImage.heightAnchor.constraint(equalTo: shadowWrapperView.widthAnchor, multiplier:0.3, constant:0).isActive = true

        let titleLabel = UILabel.init()
        titleLabel.backgroundColor = .clear
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        shadowWrapperView.addSubview(titleLabel)
        titleLabel.leadingAnchor.constraint(equalTo:shadowWrapperView.leadingAnchor, constant:20).isActive = true
        titleLabel.trailingAnchor.constraint(equalTo:shadowWrapperView.trailingAnchor, constant:-20).isActive = true
        titleLabel.topAnchor.constraint(equalTo: welcomeImage.bottomAnchor, constant:5).isActive = true
        titleLabel.attributedText = NSAttributedString(string:self.getString("welcome_appTitle"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font:UIFont(name: fontString.avenirHeavy.rawValue, size: 22)!])
        
        
        let moreInfoLabel = UILabel.init()
        moreInfoLabel.numberOfLines = 2
        moreInfoLabel.textAlignment = .center
        moreInfoLabel.translatesAutoresizingMaskIntoConstraints = false
        shadowWrapperView.addSubview(moreInfoLabel)
        moreInfoLabel.leadingAnchor.constraint(equalTo: shadowWrapperView.leadingAnchor, constant:20).isActive = true
        moreInfoLabel.trailingAnchor.constraint(equalTo: shadowWrapperView.trailingAnchor, constant:-40).isActive = true
        moreInfoLabel.topAnchor.constraint(equalTo:titleLabel.bottomAnchor, constant:2).isActive = true
        moreInfoLabel.attributedText = NSAttributedString(string:self.getString("welcome_appDescription"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:15)!])
        
        
        languageBtn.translatesAutoresizingMaskIntoConstraints = false
        shadowWrapperView.addSubview(languageBtn)
        languageBtn.topAnchor.constraint(equalTo:moreInfoLabel.bottomAnchor, constant:30).isActive = true
        languageBtn.centerXAnchor.constraint(equalTo:shadowWrapperView.centerXAnchor, constant:0).isActive = true
        languageBtn.widthAnchor.constraint(lessThanOrEqualTo: shadowWrapperView.widthAnchor, multiplier:0.6, constant:0).isActive = true
        languageBtn.heightAnchor.constraint(equalToConstant:40).isActive = true
        if self.selectedLanguage != "" {
            let langAttrString = NSAttributedString(string:self.selectedLanguage, attributes: [NSAttributedString.Key.foregroundColor: UIColor.getColor(.white), NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:16)!])
            languageBtn.setAttributedTitle(langAttrString, for:.normal)
        } else {
            let langAttrString = NSAttributedString(string:self.getString("welcome_selectLanguage"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.getColor(.base_2), NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:16)!])
            languageBtn.setAttributedTitle(langAttrString, for:.normal)
        }
        self.setPickerInteraction()
        
        let seperatorView = UIView.init()
        seperatorView.backgroundColor = UIColor.getColor(.white)
        seperatorView.translatesAutoresizingMaskIntoConstraints = false
        shadowWrapperView.addSubview(seperatorView)
        seperatorView.leadingAnchor.constraint(equalTo: shadowWrapperView.leadingAnchor, constant:60).isActive = true
        seperatorView.trailingAnchor.constraint(equalTo: shadowWrapperView.trailingAnchor, constant:-60).isActive = true
        seperatorView.topAnchor.constraint(equalTo:languageBtn.bottomAnchor, constant:0).isActive = true
        seperatorView.bottomAnchor.constraint(equalTo:shadowWrapperView.bottomAnchor, constant:-60).isActive = true
        seperatorView.heightAnchor.constraint(equalToConstant:1).isActive = true
        
        
        let searchButton = UIButton.init()
        searchButton.contentEdgeInsets = UIEdgeInsets(top:5, left:40, bottom:5, right:40)
        searchButton.isUserInteractionEnabled = true
        searchButton.translatesAutoresizingMaskIntoConstraints = false
        parentWrapperView.addSubview(searchButton)
        searchButton.trailingAnchor.constraint(equalTo: shadowWrapperView.trailingAnchor, constant:0).isActive = true
        searchButton.leadingAnchor.constraint(greaterThanOrEqualTo: shadowWrapperView.leadingAnchor, constant:10).isActive = true
        searchButton.topAnchor.constraint(equalTo: shadowWrapperView.bottomAnchor, constant:40).isActive = true
        searchButton.heightAnchor.constraint(equalToConstant:50).isActive = true
        searchButton.layer.cornerRadius = 25
        
        let searchAttrString = NSAttributedString(string:self.getString("welcome_search").uppercased(), attributes: [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font:UIFont(name:fontString.avenirBlack.rawValue, size:16)!])
        searchButton.setAttributedTitle(searchAttrString, for:.normal)
        
        searchButton.backgroundColor = UIColor.getColor(.base_1)
        searchButton.layer.shadowOffset = CGSize(width: 0, height: 2)
        searchButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.1).cgColor
        searchButton.layer.shadowOpacity = 1
        searchButton.layer.shadowRadius = 8
        
        searchButton.addTargetClosure { (_) in
            if self.selectedLanguage != "" {
                self.presentor?.showRepoListController(navigationController: self.navigationController!, selectedLanguage:self.selectedLanguage)
            }
        }
        
    }
}

//MARK:- UIPickerViewDelegate, UIPickerViewDataSource
extension WelcomeViewController : UIPickerViewDelegate, UIPickerViewDataSource {
    
    func setPickerInteraction() {
        self.languageBtn.addTargetClosure { (_) in
            
            if self.languageArray.count > 0 {
                self.selectedLanguage = self.languageArray[0]
            }
            
            self.picker = UIPickerView.init()
            self.picker.delegate = self
            self.picker.backgroundColor = UIColor.white
            self.picker.setValue(UIColor.black, forKey: "textColor")
            self.picker.autoresizingMask = .flexibleWidth
            self.picker.contentMode = .center
            self.picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
            self.view.addSubview(self.picker)

            self.toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
            self.toolBar.barStyle = .blackTranslucent
            let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
            let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.onDoneButtonTapped))
            self.toolBar.setItems([spaceButton, doneButton], animated: false)
            self.view.addSubview(self.toolBar)
        }
    }
    @objc func onDoneButtonTapped() {
        
        if self.selectedLanguage != "" {
            let langAttrString = NSAttributedString(string:self.selectedLanguage, attributes: [NSAttributedString.Key.foregroundColor: UIColor.getColor(.white), NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:16)!])
            languageBtn.setAttributedTitle(langAttrString, for:.normal)
        }
        toolBar.removeFromSuperview()
        picker.removeFromSuperview()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return languageArray.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return languageArray[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.selectedLanguage = languageArray[row]
    }
    
}

