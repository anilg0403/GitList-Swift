//
//  WelcomeRouter.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

class WelcomeRouter:PresenterToRouterProtocol{
    
    static func createModule() -> WelcomeViewController {
        
        let view = WelcomeViewController(nibName: "WelcomeViewController", bundle: nil)
        
        let presenter: ViewToPresenterProtocol = WelcomePresenter()
        let router:PresenterToRouterProtocol = WelcomeRouter()
        
        view.presentor = presenter
        presenter.view = view
        presenter.router = router
        
        return view
        
    }
    
    func pushToRepoListScreen(navigationConroller: UINavigationController, selectedLanguage: String) {
        let repoListModule = RepositoryListRouter.createRepoListModule()
        repoListModule.selectedLanguage = selectedLanguage
        navigationConroller.pushViewController(repoListModule,animated: true)
    }
    
}
