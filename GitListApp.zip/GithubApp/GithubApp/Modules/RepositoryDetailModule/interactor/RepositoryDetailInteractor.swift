//
//  RepositoryDetailInteractor.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

class RepositoryDetailInteractor : PresenterToInteractorRepoDetailProtocol{
   
    var presenter: InteractorToPresenterRepoDetailProtocol?
    
    func fetchContributorList(url: String) {
        
        URLSession.shared.dataTask(with: URL(string:url)!) { (data, response, error) in
            if error == nil{
                if let data = data {
                    do{
                        let userResponse = try JSONDecoder().decode([ContributorInfo].self, from: data)
                        self.presenter?.repoContributorFetchSuccess(contributorList:userResponse)
                        
                    }catch let err{
                        print(err.localizedDescription)
                        self.presenter?.repoContributorFetchFailed(error:err.localizedDescription)
                    }
                }
            }else{
                self.presenter?.repoContributorFetchFailed(error:error?.localizedDescription ?? "Something went wrong")
            }
        }.resume()
        
    }
    
}
