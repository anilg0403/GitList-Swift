//
//  RepositoryDetailViewController.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import UIKit

//MARK:- RepositoryDetailViewController Class
class RepositoryDetailViewController: UIViewController {
    
    //MARK:- IBOutlets
    @IBOutlet weak var parentView: UIView!
    @IBOutlet weak var repoDetailTableView: UITableView!
    
    //MARK:- Properties
    var repoDetailPresenter:ViewToPresenterRepoDetailProtocol?

    public var selectedRepoInfo : GitRepoInfo?
    var contributorList : [ContributorInfo]?

    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        repoDetailTableView.tableHeaderView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height:5))
        repoDetailTableView.tableFooterView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height: 1))
        repoDetailTableView?.separatorColor = .clear
        repoDetailTableView.backgroundColor = .clear
        repoDetailTableView.register(UINib(nibName: "InfoTableViewCell", bundle: nil), forCellReuseIdentifier: "InfoTableViewCell")
        repoDetailTableView.register(UINib(nibName: "ContributorTableViewCell", bundle: nil), forCellReuseIdentifier: "ContributorTableViewCell")
        
        if let url = selectedRepoInfo?.contributorsUrl {
            repoDetailPresenter?.startFetchingContributorInfo(url:url)
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = self.getString("repository_detail_navbarTitle")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.title = ""
    }

}

//MARK:- conform to Protocols
extension RepositoryDetailViewController : PresenterToViewRepoDetailProtocol{
    func onContributorResponseSuccess(contributorList: [ContributorInfo]) {
        if contributorList.count > 0 {
            self.contributorList = contributorList
            DispatchQueue.main.async {
                self.repoDetailTableView.reloadData()
            }
        }
    }
    
    func onContributorResponseFailed(error: String) {
        //Don't show Contributor list on Failure
    }
    
}

//MARK:- UITableViewDelegate & UITableViewDataSource Methods
extension RepositoryDetailViewController : UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if contributorList?.count ?? 0 > 0 {
            return 2
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else if contributorList?.count ?? 0 > 0 {
            return contributorList?.count ?? 0
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let sectionTitleView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        sectionTitleView.backgroundColor = .clear
        
        let titleLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        sectionTitleView.addSubview(titleLabel)
        titleLabel.leadingAnchor.constraint(equalTo: sectionTitleView.leadingAnchor ,constant: 10).isActive = true
        titleLabel.centerYAnchor.constraint(equalTo: sectionTitleView.centerYAnchor ,constant:0).isActive = true
        titleLabel.trailingAnchor.constraint(equalTo: sectionTitleView.trailingAnchor ,constant: -10).isActive = true
        
        var headerTitle = ""
        if section == 0 {
            headerTitle = self.getString("repository_detail_repositoryInfo")
        } else if section == 1 {
            headerTitle = self.getString("repository_detail_contributorInfo")
        }
        
        titleLabel.attributedText = NSAttributedString(string:headerTitle , attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name: fontString.avenirHeavy.rawValue, size: 17)!])
        
        return sectionTitleView
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier:"InfoTableViewCell", for: indexPath) as! InfoTableViewCell
            cell.parentView.removeAllSubviews()
            cell.selectedRepoInfo = self.selectedRepoInfo
            
            cell.parentView.layer.masksToBounds = false
            cell.parentView.layer.shadowColor = UIColor.lightGray.cgColor
            cell.parentView.layer.shadowOffset = CGSize(width:1, height: 1)
            cell.parentView.layer.shadowOpacity = 1.0
            cell.parentView.layer.shadowRadius = 1.0
            cell.parentView.layer.cornerRadius = 8
            return cell
                
        } else {
            
            let currentIndexObj = self.contributorList?[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier:"ContributorTableViewCell", for: indexPath) as! ContributorTableViewCell
            
            if currentIndexObj?.userName != nil && currentIndexObj?.userName != "" {
                cell.nameLabel.attributedText = NSAttributedString(string:(currentIndexObj?.userName ?? "").capitalized, attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:17)!])
            } else {
                cell.nameLabel.text = ""
            }
            
            if currentIndexObj?.contributions != nil {
                cell.contributionLabel.attributedText = NSAttributedString(string: ("\(self.getString("repository_detail_contributor")) : " + "\(currentIndexObj?.contributions ?? 0)"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name: fontString.avenirBook.rawValue, size: 15)!])
            } else {
                cell.contributionLabel.attributedText = NSAttributedString(string:"\(self.getString("repository_detail_contributor")) : 0", attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name: fontString.avenirBook.rawValue, size: 15)!])
            }
            
            if currentIndexObj?.avatarUrl != nil && currentIndexObj?.avatarUrl != "" {
                cell.userImageView.setImage(from:URL(string:currentIndexObj?.avatarUrl ?? "")!, withPlaceholder:UIImage(named:"profilePlaceholder"))
            } else {
                cell.userImageView.image = UIImage(named:"profilePlaceholder")
            }
            
            cell.parentView.layer.masksToBounds = false
            cell.parentView.layer.shadowColor = UIColor.lightGray.cgColor
            cell.parentView.layer.shadowOffset = CGSize(width:1, height: 1)
            cell.parentView.layer.shadowOpacity = 1.0
            cell.parentView.layer.shadowRadius = 1.0
            cell.parentView.layer.cornerRadius = 8
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

