//
//  InfoTableViewCell.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import UIKit

class InfoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var parentView: UIView!
    
    var selectedRepoInfo: GitRepoInfo?{
        didSet{
            addRepositoryMoreInfo()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    func addRepositoryMoreInfo() {
        
        let subviewCount = 4 //normally response count is taken however current response is not ARRAY so hardcoded for now
        var lastUIViewRef = parentView
        
        for i in 0...(subviewCount - 1) {
            
            let infoWrapperView = UIView.init()
            parentView.addSubview(infoWrapperView)
            infoWrapperView.translatesAutoresizingMaskIntoConstraints = false
            
            if i == 0 {
                infoWrapperView.topAnchor.constraint(equalTo: lastUIViewRef!.topAnchor, constant:15).isActive = true
                infoWrapperView.leadingAnchor.constraint(equalTo: parentView.leadingAnchor, constant:10).isActive = true
                infoWrapperView.widthAnchor.constraint(equalTo: parentView.widthAnchor, multiplier:0.5, constant:-15).isActive = true
            } else if (i%2 == 0) {
                infoWrapperView.topAnchor.constraint(equalTo:lastUIViewRef!.bottomAnchor, constant:10).isActive = true
                infoWrapperView.leadingAnchor.constraint(equalTo: parentView.leadingAnchor, constant:10).isActive = true
                infoWrapperView.widthAnchor.constraint(equalTo: parentView.widthAnchor, multiplier:0.5, constant:-15).isActive = true
                                    
            } else {
                infoWrapperView.topAnchor.constraint(equalTo: lastUIViewRef!.topAnchor, constant:0).isActive = true
                infoWrapperView.leadingAnchor.constraint(equalTo: lastUIViewRef!.trailingAnchor, constant:10).isActive = true
                infoWrapperView.trailingAnchor.constraint(equalTo: parentView.trailingAnchor, constant:-5).isActive = true
            }
            
            let infoTitleLabel = UILabel.init()
            infoWrapperView.addSubview(infoTitleLabel)
            infoTitleLabel.translatesAutoresizingMaskIntoConstraints = false
            infoTitleLabel.topAnchor.constraint(equalTo:infoWrapperView.topAnchor, constant:0).isActive = true
            infoTitleLabel.leadingAnchor.constraint(equalTo:infoWrapperView.leadingAnchor, constant:0).isActive = true
            infoTitleLabel.trailingAnchor.constraint(equalTo:infoWrapperView.trailingAnchor, constant:0).isActive = true
            
            let infoValueLabel = UILabel.init()
            infoWrapperView.addSubview(infoValueLabel)
            infoValueLabel.translatesAutoresizingMaskIntoConstraints = false
            infoValueLabel.topAnchor.constraint(equalTo:infoTitleLabel.bottomAnchor, constant:0).isActive = true
            infoValueLabel.leadingAnchor.constraint(equalTo:infoWrapperView.leadingAnchor, constant:0).isActive = true
            infoValueLabel.trailingAnchor.constraint(equalTo:infoWrapperView.trailingAnchor, constant:0).isActive = true
            infoValueLabel.bottomAnchor.constraint(equalTo:infoWrapperView.bottomAnchor, constant:0).isActive = true
            
            var titleString = ""
            var valueString = 0
            switch i {
            case 0:
                titleString = "Size"
                valueString = selectedRepoInfo?.size ?? 0
            case 1:
                titleString = "Stargazer Count"
                valueString = selectedRepoInfo?.stargazersCount ?? 0
            case 2:
                titleString = "Watcher Count"
                valueString = selectedRepoInfo?.watchersCount ?? 0
            case 3:
                titleString = "Fork Count"
                valueString = selectedRepoInfo?.forksCount ?? 0
            default:
                titleString = ""
                valueString = 0
            }
            
            infoTitleLabel.attributedText = NSAttributedString(string:titleString, attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:17)!])
            infoValueLabel.attributedText = NSAttributedString(string:"\(valueString)" , attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size: 15)!])
            
            lastUIViewRef = infoWrapperView
            
        }
        
        lastUIViewRef!.bottomAnchor.constraint(equalTo:parentView.bottomAnchor, constant:-15).isActive = true
        
    }
    
}
