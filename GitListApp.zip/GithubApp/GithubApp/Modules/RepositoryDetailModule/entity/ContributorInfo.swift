//
//  ContributorInfo.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

struct ContributorInfo :  Codable {

    let id : Int?
    let userName : String?
    let avatarUrl : String?
    let contributions : Int?
    
    enum CodingKeys: String, CodingKey {
        case id
        case userName = "login"
        case avatarUrl = "avatar_url"
        case contributions
    }
}
