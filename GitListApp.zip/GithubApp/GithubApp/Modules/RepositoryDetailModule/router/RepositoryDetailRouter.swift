//
//  RepositoryDetailRouter.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

class RepositoryDetailRouter : PresenterToRouterRepoDetailProtocol{
    
    static func createRepoDetailModule() -> RepositoryDetailViewController {
        
        let view = RepositoryDetailViewController(nibName: "RepositoryDetailViewController", bundle: nil)
        
        let presenter: ViewToPresenterRepoDetailProtocol & InteractorToPresenterRepoDetailProtocol = RepositoryDetailPresenter()
        let interactor: PresenterToInteractorRepoDetailProtocol = RepositoryDetailInteractor()
        let router:PresenterToRouterRepoDetailProtocol = RepositoryDetailRouter()
        
        view.repoDetailPresenter = presenter
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        interactor.presenter = presenter
        
        return view
        
    }
    
    
}
