//
//  RepositoryDetailPresenter.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

class RepositoryDetailPresenter : ViewToPresenterRepoDetailProtocol{
    
    var interactor: PresenterToInteractorRepoDetailProtocol?
    weak var view: PresenterToViewRepoDetailProtocol?
    var router: PresenterToRouterRepoDetailProtocol?
    
    func startFetchingContributorInfo(url: String) {
        interactor?.fetchContributorList(url:url)
    }
    
}

extension RepositoryDetailPresenter : InteractorToPresenterRepoDetailProtocol{
    
    func repoContributorFetchSuccess(contributorList: [ContributorInfo]) {
        view?.onContributorResponseSuccess(contributorList:contributorList)
    }
    
    func repoContributorFetchFailed(error: String) {
        view?.onContributorResponseFailed(error:error)
    }
    
}
