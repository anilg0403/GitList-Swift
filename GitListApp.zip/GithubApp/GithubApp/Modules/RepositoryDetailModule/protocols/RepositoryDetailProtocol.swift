//
//  RepositoryDetailProtocol.swift
//  GithubApp
//
//  Created by Anil Gupta on 07/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

protocol ViewToPresenterRepoDetailProtocol:class{
    var view: PresenterToViewRepoDetailProtocol? {get set}
    var interactor: PresenterToInteractorRepoDetailProtocol? {get set}
    var router: PresenterToRouterRepoDetailProtocol? {get set}
    func startFetchingContributorInfo(url:String)
}

protocol PresenterToViewRepoDetailProtocol:class {
    func onContributorResponseSuccess(contributorList:[ContributorInfo])
    func onContributorResponseFailed(error:String)
}

protocol PresenterToRouterRepoDetailProtocol:class {
    static func createRepoDetailModule()->RepositoryDetailViewController
    //func pushToRepoDetailScreen(navigationConroller: UINavigationController,selectedRepoInfo:GitRepoInfo)
}

protocol PresenterToInteractorRepoDetailProtocol:class {
    
    var presenter:InteractorToPresenterRepoDetailProtocol? {get set}
    func fetchContributorList(url:String)
    
}

protocol InteractorToPresenterRepoDetailProtocol:class {
    func repoContributorFetchSuccess(contributorList:[ContributorInfo])
    func repoContributorFetchFailed(error:String)
}
