//
//  GitRepoObj.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

struct GitRepoObj :  Codable {
    
    let total_count : Int?
    let incomplete_results : Bool?
    let repoList : [GitRepoInfo]?
    
    enum CodingKeys: String, CodingKey {
        case total_count
        case incomplete_results
        case repoList = "items"
    }

}
