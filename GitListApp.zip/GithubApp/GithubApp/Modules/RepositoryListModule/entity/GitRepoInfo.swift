//
//  GitRepoInfo.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

struct GitRepoInfo :  Codable {

    let id : Int?
    let nodeId : String?
    let name : String?
    let fullName : String?
    let description : String?
    let size : Int?
    let stargazersCount : Int?
    let watchersCount : Int?
    let forksCount : Int?
    let contributorsUrl : String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case nodeId = "node_id"
        case name
        case fullName = "full_name"
        case description
        case size
        case stargazersCount = "stargazers_count"
        case watchersCount = "watchers_count"
        case forksCount = "forks_count"
        case contributorsUrl = "contributors_url"
    }
}
