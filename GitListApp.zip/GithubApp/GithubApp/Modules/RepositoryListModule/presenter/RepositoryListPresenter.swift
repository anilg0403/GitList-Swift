//
//  RepositoryListPresenter.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

//MARK:- RepositoryListPresenter : View -> Presenter
class RepositoryListPresenter:ViewToPresenterRepoListProtocol{
    
    weak var view: PresenterToViewRepoListProtocol?
    var interactor: PresenterToInteractorRepoListProtocol?
    var router: PresenterToRouterRepoListProtocol?
    
    func startFetchingRepoList(language: String, currentPageNumber: Int, perPageCount: Int) {
        interactor?.fetchAllRepos(language:language, currentPageNumber:currentPageNumber, perPageCount:perPageCount)
    }
    
    func showRepoDetailController(navigationController: UINavigationController, selectedRepoInfo: GitRepoInfo) {
        router?.pushToRepoDetailScreen(navigationConroller:navigationController, selectedRepoInfo:selectedRepoInfo)
    }
    
}

//MARK:- RepositoryListPresenter : Interactor -> Presenter
extension RepositoryListPresenter : InteractorToPresenterRepoListProtocol{
    
    func repoListFetchSuccess(repoObjModel: GitRepoObj, currentPageNumber: Int) {
        view?.onRepoListResponseSuccess(repoObjModel:repoObjModel, currentPageNumber:currentPageNumber)
    }
    
    func repoListFetchFailed(error: String) {
        view?.onRepoListResponseFailed(error:error)
        
    }
    
}
