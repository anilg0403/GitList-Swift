//
//  RepositoryListInteractor.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation

class RepositoryListInteractor:PresenterToInteractorRepoListProtocol{
    
    var presenter: InteractorToPresenterRepoListProtocol?
    
    func fetchAllRepos(language: String, currentPageNumber: Int, perPageCount: Int) {
        
        var urlString = API_REPO_LIST
        let concatString = String("\(language.lowercased())" + "&page=" + "\(currentPageNumber)" + "&per_page=" + "\(perPageCount)")
       urlString = urlString + concatString
        
        URLSession.shared.dataTask(with: URL(string:urlString)!) { (data, response, error) in
            if error == nil{
                if let data = data {
                    do{
                        let userResponse = try JSONDecoder().decode(GitRepoObj.self, from: data)
                        self.presenter?.repoListFetchSuccess(repoObjModel:userResponse, currentPageNumber:currentPageNumber)
                    }catch let err{
                        self.presenter?.repoListFetchFailed(error:err.localizedDescription)
                    }
                }
            }else{
                self.presenter?.repoListFetchFailed(error:error?.localizedDescription ?? "Something went wrong")
            }
        }.resume()
        
    }
    
}
