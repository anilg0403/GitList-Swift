//
//  RepositoryListViewController.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import UIKit
import Foundation

//MARK:- RepositoryListViewController Class
class RepositoryListViewController: UIViewController {
    
    //MARK:- IBOutlets
    @IBOutlet weak var parentView: UIView!
    @IBOutlet weak var repoListTableView: UITableView!
    
    @IBOutlet weak var pageNavigationWrapperView: UIView!
    @IBOutlet weak var prevButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var pagesCountLabel: UILabel!
    
    @IBOutlet weak var rightActivityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var leftActivityIndicator: UIActivityIndicatorView!

    
    //MARK:- Properties
    var repoListPresenter:ViewToPresenterRepoListProtocol?

    public var selectedLanguage : String?
    var gitRepoObject : GitRepoObj?
    var gitInfoList : [GitRepoInfo]?
    var totalRepoCount = 0
    var currentPageNo = 1
    var perPageRepoCount = 25
    var lastPageNo = 0
    
    
    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        repoListPresenter?.startFetchingRepoList(language: selectedLanguage ?? "", currentPageNumber:currentPageNo, perPageCount:perPageRepoCount)
        self.addFetchingView()
        
        repoListTableView.tableHeaderView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height:1))
        repoListTableView.tableFooterView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 10, height: 1))
        repoListTableView?.separatorColor = .clear
        repoListTableView.backgroundColor = .clear
        repoListTableView.register(UINib(nibName: "UserInfoTableViewCell", bundle: nil), forCellReuseIdentifier: "UserInfoTableViewCell")
        
        self.pageNavigationWrapperView.isHidden = true
        self.prevButton.setImage(UIImage(named:"prevArrow"), for:.normal)
        self.nextButton.setImage(UIImage(named:"nextArrow"), for:.normal)
        self.setNavigationButtonGesture()
                
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = self.getString("repository_list_navbarTitle")
        self.navigationController?.navigationBar.isHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.title = ""
    }
    
    //MARK:- UI Setup & Other functions
    func setUI() {
        DispatchQueue.main.async {
            if self.totalRepoCount > 0 {
                
                self.pageNavigationWrapperView.isHidden = false
                
                if self.totalRepoCount < self.perPageRepoCount {
                    self.lastPageNo = 1
                } else {
                    let floatLastPageNo : CGFloat = CGFloat(self.totalRepoCount/self.perPageRepoCount)
                    self.lastPageNo = Int(ceil(floatLastPageNo))
                    if CGFloat(self.totalRepoCount%self.perPageRepoCount) > 0 {
                        self.lastPageNo = self.lastPageNo + 1
                    }
                }
                
                self.prevButton.isHidden = (self.currentPageNo == 1) ? true : false
                self.nextButton.isHidden = (self.currentPageNo == self.lastPageNo) ? true : false
                
                self.pagesCountLabel.attributedText = NSAttributedString(string:"Page \(self.currentPageNo) of \(self.lastPageNo)", attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirMedium.rawValue, size:15)!])
                
            } else {
                self.pageNavigationWrapperView.isHidden = true
            }
        }
    }
    
    func setNavigationButtonGesture() {
        self.prevButton.addTargetClosure { (_) in
            self.resetNaviagtionBtnInteraction(false)
            self.leftActivityIndicator.startAnimating()
            self.repoListPresenter?.startFetchingRepoList(language: self.selectedLanguage ?? "", currentPageNumber:(self.currentPageNo - 1), perPageCount:self.perPageRepoCount)
        }
        
        self.nextButton.addTargetClosure { (_) in
            self.resetNaviagtionBtnInteraction(false)
            self.rightActivityIndicator.startAnimating()
            self.repoListPresenter?.startFetchingRepoList(language: self.selectedLanguage ?? "", currentPageNumber:(self.currentPageNo + 1), perPageCount:self.perPageRepoCount)
        }
    }
    
    func resetNaviagtionBtnInteraction(_ setValue:Bool) {
        DispatchQueue.main.async {
            self.prevButton.isUserInteractionEnabled = setValue
            self.nextButton.isUserInteractionEnabled = setValue
            
            if setValue {
                self.rightActivityIndicator.stopAnimating()
                self.leftActivityIndicator.stopAnimating()
            }
        }
    }

}

//MARK:- conform to Protocols 
extension RepositoryListViewController : PresenterToViewRepoListProtocol{
    
    func onRepoListResponseSuccess(repoObjModel: GitRepoObj, currentPageNumber: Int) {
        self.removeFetchingView()
        self.resetNaviagtionBtnInteraction(true)
        
        self.gitInfoList = []
        if repoObjModel.repoList?.count ?? 0 > 0 {
            self.gitInfoList = repoObjModel.repoList
            DispatchQueue.main.async {
                self.repoListTableView.reloadData()
            }
        }
        
        self.currentPageNo = currentPageNumber
        if repoObjModel.total_count != nil {
            self.totalRepoCount = repoObjModel.total_count ?? 0
        } else {
            self.totalRepoCount = 0
        }
        self.setUI()
    }
    
    func onRepoListResponseFailed(error: String) {
        self.removeFetchingView()
        self.resetNaviagtionBtnInteraction(true)
        self.showToast(message:error, font:UIFont(name:fontString.avenirMedium.rawValue, size:15)!)
    }
    
}

//MARK:- UITableViewDelegate, UITableViewDataSource
extension RepositoryListViewController : UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.gitInfoList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if let currentIndexObj = self.gitInfoList?[indexPath.row] {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "UserInfoTableViewCell", for: indexPath) as! UserInfoTableViewCell
            
            if currentIndexObj.name != nil && currentIndexObj.name != "" {
                cell.nameTitle.attributedText = NSAttributedString(string:self.getString("repository_list_name"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:15)!])
                cell.nameValue.attributedText = NSAttributedString(string: currentIndexObj.name ?? "" , attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirHeavy.rawValue, size: 16)!])
            } else {
                cell.nameTitle.text = ""
                cell.nameValue.text = ""
            }
            
            if currentIndexObj.fullName != nil && currentIndexObj.fullName != "" {
                cell.fullnameTitle.attributedText = NSAttributedString(string:self.getString("repository_list_fullname"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:15)!])
                cell.fullnameValue.attributedText = NSAttributedString(string: currentIndexObj.fullName ?? "" , attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name: fontString.avenirHeavy.rawValue, size: 16)!])
            } else {
                cell.fullnameTitle.text = ""
                cell.fullnameValue.text = ""
            }
            
            if currentIndexObj.description != nil && currentIndexObj.description != "" {
                cell.descriptionTitle.attributedText = NSAttributedString(string:self.getString("repository_list_description"), attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirBook.rawValue, size:15)!])
                cell.descriptionValue.attributedText = NSAttributedString(string: currentIndexObj.description ?? "" , attributes: [NSAttributedString.Key.foregroundColor: UIColor.black, NSAttributedString.Key.font:UIFont(name:fontString.avenirMedium.rawValue, size: 16)!])
            } else {
                cell.descriptionTitle.text = ""
                cell.descriptionValue.text = ""
            }
            
            cell.parentView.layer.masksToBounds = false
            cell.parentView.layer.shadowColor = UIColor.lightGray.cgColor
            cell.parentView.layer.shadowOffset = CGSize(width:1, height: 1)
            cell.parentView.layer.shadowOpacity = 1.0
            cell.parentView.layer.shadowRadius = 1.0
            cell.parentView.layer.cornerRadius = 8
            
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let selectedInfo = self.gitInfoList?[indexPath.row] {
            repoListPresenter?.showRepoDetailController(navigationController: self.navigationController!, selectedRepoInfo:selectedInfo)
        }
    }
    
}


extension RepositoryListViewController {
    
    
}
