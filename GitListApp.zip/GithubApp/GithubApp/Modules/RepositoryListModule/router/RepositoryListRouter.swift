//
//  RepositoryListRouter.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

class RepositoryListRouter:PresenterToRouterRepoListProtocol{
    
    static func createRepoListModule() -> RepositoryListViewController {
        
        let view = RepositoryListViewController(nibName: "RepositoryListViewController", bundle: nil)
        
        let presenter: ViewToPresenterRepoListProtocol & InteractorToPresenterRepoListProtocol = RepositoryListPresenter()
        let interactor: PresenterToInteractorRepoListProtocol = RepositoryListInteractor()
        let router:PresenterToRouterRepoListProtocol = RepositoryListRouter()
        
        view.repoListPresenter = presenter
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        interactor.presenter = presenter
        
        return view
        
    }
    
    func pushToRepoDetailScreen(navigationConroller: UINavigationController, selectedRepoInfo: GitRepoInfo) {
        let repoDetailModule = RepositoryDetailRouter.createRepoDetailModule()
        repoDetailModule.selectedRepoInfo = selectedRepoInfo
        navigationConroller.pushViewController(repoDetailModule,animated: true)
    }
    
}
