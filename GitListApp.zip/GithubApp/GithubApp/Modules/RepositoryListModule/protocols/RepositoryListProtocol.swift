//
//  RepositoryListProtocol.swift
//  GithubApp
//
//  Created by Anil Gupta on 06/06/20.
//  Copyright © 2020 Anil Gupta. All rights reserved.
//

import Foundation
import UIKit

protocol ViewToPresenterRepoListProtocol:class{
    var view: PresenterToViewRepoListProtocol? {get set}
    var interactor: PresenterToInteractorRepoListProtocol? {get set}
    var router: PresenterToRouterRepoListProtocol? {get set}
    func startFetchingRepoList(language:String,currentPageNumber:Int,perPageCount:Int)
    func showRepoDetailController(navigationController:UINavigationController, selectedRepoInfo:GitRepoInfo)
}

protocol PresenterToViewRepoListProtocol:class {
    func onRepoListResponseSuccess(repoObjModel:GitRepoObj,currentPageNumber:Int)
    func onRepoListResponseFailed(error:String)
}

protocol PresenterToRouterRepoListProtocol:class {
    static func createRepoListModule()->RepositoryListViewController
    func pushToRepoDetailScreen(navigationConroller: UINavigationController,selectedRepoInfo:GitRepoInfo)
}

protocol PresenterToInteractorRepoListProtocol:class {
    var presenter:InteractorToPresenterRepoListProtocol? {get set}
    func fetchAllRepos(language:String,currentPageNumber:Int,perPageCount:Int)
}

protocol InteractorToPresenterRepoListProtocol:class {
    func repoListFetchSuccess(repoObjModel:GitRepoObj,currentPageNumber:Int)
    func repoListFetchFailed(error:String)
}
